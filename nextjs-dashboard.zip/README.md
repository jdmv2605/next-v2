# Biomédica Pro - Dashboard

## 📋 Descripción del Proyecto
Dashboard especializado en gestión biomédica, desarrollado con Next.js como parte del curso de aprendizaje.

## 🎨 Personalizaciones Implementadas

### Cambios Visuales
- ✅ **Logo personalizado:** "Biomédica Pro" 
- ✅ **Paleta de colores:** Verde biomédica (verde-600, emerald-700, green-50)
- ✅ **Tipografía:** Poppins para mejor legibilidad
- ✅ **Layout:** Navegación reorganizada en header
- ✅ **Imágenes:** 3 imágenes personalizadas del sector salud

### Cambios de Contenido
- ✅ **Datos temáticos:** Instituciones médicas y servicios de salud
- ✅ **Textos en español:** Interfaz completamente localizada
- ✅ **Funcionalidad agregada:** Botón "Página Principal" en navegación

## 🛠 Tecnologías Utilizadas
- **Frontend:** Next.js 15, React, TypeScript
- **Estilos:** Tailwind CSS
- **Base de datos:** PostgreSQL + Neon
- **Autenticación:** NextAuth.js
- **Despliegue:** Vercel

## 🚀 Características Principales
- Gestión de facturas médicas
- Administración de clientes (instituciones de salud)
- Autenticación segura
- Búsqueda y paginación

## 🔧 Instalación y Ejecución
```bash
# Instalar dependencias
pnpm install

# Ejecutar en desarrollo
pnpm run dev

# Sembrar base de datos
pnpm run seed